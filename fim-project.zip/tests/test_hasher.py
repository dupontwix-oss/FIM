import os
import tempfile
from fim.hasher import compute_hash, get_file_metadata


def test_compute_hash_deterministic():
    with tempfile.NamedTemporaryFile(delete=False, mode="w") as f:
        f.write("contenu de test")
        path = f.name
    try:
        h1 = compute_hash(path, "sha256")
        h2 = compute_hash(path, "sha256")
        assert h1 == h2
        assert len(h1) == 64  # sha256 hex digest
    finally:
        os.remove(path)


def test_hash_changes_on_modification():
    with tempfile.NamedTemporaryFile(delete=False, mode="w") as f:
        f.write("version 1")
        path = f.name
    try:
        h1 = compute_hash(path)
        with open(path, "w") as f:
            f.write("version 2")
        h2 = compute_hash(path)
        assert h1 != h2
    finally:
        os.remove(path)


def test_get_file_metadata():
    with tempfile.NamedTemporaryFile(delete=False, mode="w") as f:
        f.write("abc")
        path = f.name
    try:
        meta = get_file_metadata(path)
        assert meta["size"] == 3
        assert "mtime" in meta
    finally:
        os.remove(path)
