"""Surveillance temps réel des fichiers via watchdog (inotify / FSEvents / ReadDirectoryChangesW)."""
import logging
import threading

from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

from fim.hasher import compute_hash, get_file_metadata
from fim.database import FileBaseline, FIMEvent
from fim.scanner import is_excluded
from fim.notifier import notify

logger = logging.getLogger("fim")


class FIMHandler(FileSystemEventHandler):
    def __init__(self, session_factory, config):
        # session_factory: callable qui retourne une nouvelle session SQLAlchemy
        # (watchdog appelle les handlers depuis un thread dédié -> session par événement)
        self.session_factory = session_factory
        self.config = config
        self._lock = threading.Lock()

    def _excluded(self, path: str) -> bool:
        return is_excluded(path, self.config.exclude_patterns)

    def on_created(self, event):
        if event.is_directory or self._excluded(event.src_path):
            return
        with self._lock:
            self._handle_created(event.src_path)

    def on_modified(self, event):
        if event.is_directory or self._excluded(event.src_path):
            return
        with self._lock:
            self._handle_modified(event.src_path)

    def on_deleted(self, event):
        if event.is_directory or self._excluded(event.src_path):
            return
        with self._lock:
            self._handle_deleted(event.src_path)

    def on_moved(self, event):
        if event.is_directory:
            return
        with self._lock:
            self._handle_deleted(event.src_path, event_type="MOVED", details=f"Déplacé vers {event.dest_path}")
            if not self._excluded(event.dest_path):
                self._handle_created(event.dest_path)

    # --- logique interne ---

    def _handle_created(self, path):
        session = self.session_factory()
        try:
            file_hash = compute_hash(path, self.config.hash_algorithm)
            meta = get_file_metadata(path)
        except (FileNotFoundError, PermissionError):
            session.close()
            return

        existing = session.query(FileBaseline).filter_by(path=path).first()
        if existing:
            session.close()
            return  # déjà connu, ignorer (peut être un doublon d'événement OS)

        session.add(FileBaseline(path=path, hash=file_hash, size=meta["size"],
                                  mtime=meta["mtime"], permissions=meta["permissions"],
                                  owner=meta["owner"]))
        session.add(FIMEvent(path=path, event_type="CREATED", new_hash=file_hash))
        session.commit()
        session.close()
        notify(self.config, "CREATED", path, "Nouveau fichier créé")

    def _handle_modified(self, path):
        session = self.session_factory()
        try:
            file_hash = compute_hash(path, self.config.hash_algorithm)
            meta = get_file_metadata(path)
        except (FileNotFoundError, PermissionError):
            session.close()
            return

        baseline = session.query(FileBaseline).filter_by(path=path).first()
        if baseline is None:
            session.add(FileBaseline(path=path, hash=file_hash, size=meta["size"],
                                      mtime=meta["mtime"], permissions=meta["permissions"],
                                      owner=meta["owner"]))
            session.add(FIMEvent(path=path, event_type="CREATED", new_hash=file_hash))
            session.commit()
            session.close()
            notify(self.config, "CREATED", path, "Nouveau fichier détecté")
            return

        if baseline.hash != file_hash:
            session.add(FIMEvent(path=path, event_type="MODIFIED",
                                  old_hash=baseline.hash, new_hash=file_hash))
            baseline.hash = file_hash
            baseline.size = meta["size"]
            baseline.mtime = meta["mtime"]
            session.commit()
            session.close()
            notify(self.config, "MODIFIED", path, "Contenu du fichier modifié")
        else:
            session.close()

    def _handle_deleted(self, path, event_type="DELETED", details=""):
        session = self.session_factory()
        baseline = session.query(FileBaseline).filter_by(path=path).first()
        if baseline is None:
            session.close()
            return
        session.add(FIMEvent(path=path, event_type=event_type, old_hash=baseline.hash, details=details))
        session.delete(baseline)
        session.commit()
        session.close()
        notify(self.config, event_type, path, details or "Fichier supprimé")


def start_watching(session_factory, config):
    """Démarre l'observation temps réel. Bloquant : à lancer dans le thread principal
    ou dans un thread dédié si combiné avec le rescan périodique."""
    observer = Observer()
    handler = FIMHandler(session_factory, config)

    for path in config.watch_paths:
        observer.schedule(handler, path, recursive=True)
        logger.info(f"Surveillance temps réel active sur : {path}")

    observer.start()
    return observer
