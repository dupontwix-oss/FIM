"""Point d'entrée unique pour déclencher les alertes configurées."""
import logging
from fim.alerts.email_alert import send_email_alert
from fim.alerts.slack_alert import send_slack_alert

logger = logging.getLogger("fim")


def notify(config, event_type: str, path: str, details: str = ""):
    subject = f"[FIM ALERT] {event_type}: {path}"
    body = (
        f"Type d'événement : {event_type}\n"
        f"Fichier          : {path}\n"
        f"Détails          : {details}\n"
    )

    logger.warning(body.replace("\n", " | "))

    sent_any = False
    if config.email.enabled:
        sent_any |= send_email_alert(config.email, subject, body)
    if config.slack.enabled:
        slack_msg = f":rotating_light: *{event_type}* détecté sur `{path}`\n{details}"
        sent_any |= send_slack_alert(config.slack, slack_msg)

    return sent_any
