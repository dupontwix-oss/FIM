"""Envoi d'alertes via webhook Slack."""
import logging
import requests

logger = logging.getLogger("fim")


def send_slack_alert(config, message: str) -> bool:
    if not config.enabled or not config.webhook_url:
        return False

    try:
        resp = requests.post(config.webhook_url, json={"text": message}, timeout=10)
        resp.raise_for_status()
        return True
    except Exception as e:
        logger.error(f"Échec de l'envoi de l'alerte Slack: {e}")
        return False
