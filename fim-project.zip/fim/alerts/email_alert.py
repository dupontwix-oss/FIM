"""Envoi d'alertes par email via SMTP."""
import smtplib
import logging
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

logger = logging.getLogger("fim")


def send_email_alert(config, subject: str, body: str) -> bool:
    if not config.enabled:
        return False

    try:
        msg = MIMEMultipart()
        msg["From"] = config.from_addr
        msg["To"] = ", ".join(config.to_addrs)
        msg["Subject"] = subject
        msg.attach(MIMEText(body, "plain"))

        with smtplib.SMTP(config.smtp_server, config.smtp_port, timeout=10) as server:
            if config.use_tls:
                server.starttls()
            if config.username:
                server.login(config.username, config.password)
            server.sendmail(config.from_addr, config.to_addrs, msg.as_string())
        return True
    except Exception as e:
        logger.error(f"Échec de l'envoi de l'alerte email: {e}")
        return False
