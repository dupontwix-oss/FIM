"""Modèles et session SQLAlchemy pour la baseline et le journal d'événements."""
from datetime import datetime, timezone

from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime, Text
from sqlalchemy.orm import declarative_base, sessionmaker

Base = declarative_base()


class FileBaseline(Base):
    """État de référence connu d'un fichier surveillé."""
    __tablename__ = "file_baseline"

    id = Column(Integer, primary_key=True)
    path = Column(String(4096), unique=True, nullable=False, index=True)
    hash = Column(String(128), nullable=False)
    size = Column(Integer, nullable=False)
    mtime = Column(Float, nullable=False)
    permissions = Column(String(16), nullable=True)
    owner = Column(String(128), nullable=True)
    last_checked = Column(DateTime, default=lambda: datetime.now(timezone.utc))


class FIMEvent(Base):
    """Journal immuable de tous les événements d'intégrité détectés."""
    __tablename__ = "fim_event"

    id = Column(Integer, primary_key=True)
    path = Column(String(4096), nullable=False, index=True)
    event_type = Column(String(32), nullable=False)   # CREATED, MODIFIED, DELETED, MOVED, PERMISSION_CHANGED
    old_hash = Column(String(128), nullable=True)
    new_hash = Column(String(128), nullable=True)
    details = Column(Text, nullable=True)
    timestamp = Column(DateTime, default=lambda: datetime.now(timezone.utc), index=True)
    alert_sent = Column(Integer, default=0)  # 0/1, évite les doubles alertes en cas de retry


def get_engine(db_config):
    if db_config.type == "postgresql":
        if not db_config.url:
            raise ValueError("database.url est requis pour le type 'postgresql'")
        return create_engine(db_config.url)
    # sqlite par défaut
    return create_engine(f"sqlite:///{db_config.path}")


def init_db(db_config):
    engine = get_engine(db_config)
    Base.metadata.create_all(engine)
    return engine


def get_session(engine):
    Session = sessionmaker(bind=engine)
    return Session()
