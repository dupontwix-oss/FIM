"""Calcul de hash cryptographique de fichiers, par blocs pour supporter les gros fichiers."""
import hashlib
import os


ALGO_MAP = {
    "sha256": hashlib.sha256,
    "sha512": hashlib.sha512,
    "sha1": hashlib.sha1,   # déconseillé, présent pour compatibilité
}


def compute_hash(filepath: str, algorithm: str = "sha256", chunk_size: int = 65536) -> str:
    algo = ALGO_MAP.get(algorithm.lower())
    if algo is None:
        raise ValueError(f"Algorithme de hash non supporté: {algorithm}")

    h = algo()
    with open(filepath, "rb") as f:
        while chunk := f.read(chunk_size):
            h.update(chunk)
    return h.hexdigest()


def get_file_metadata(filepath: str) -> dict:
    st = os.stat(filepath)
    return {
        "size": st.st_size,
        "mtime": st.st_mtime,
        "permissions": oct(st.st_mode)[-4:],
        "owner": str(st.st_uid),
    }
