"""Interface en ligne de commande : init, monitor, status, report."""
import argparse
import logging
import time
import threading
import sys

from fim.config import load_config
from fim.database import init_db, get_session, FIMEvent, FileBaseline
from fim.scanner import build_baseline, full_rescan
from fim.watcher import start_watching


def setup_logging(log_file: str):
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
        handlers=[logging.FileHandler(log_file), logging.StreamHandler(sys.stdout)],
    )


def cmd_init(args):
    config = load_config(args.config)
    setup_logging(config.log_file)
    engine = init_db(config.database)
    session = get_session(engine)
    print("Construction de la baseline initiale, cela peut prendre du temps...")
    count = build_baseline(session, config)
    session.close()
    print(f"OK : {count} fichiers enregistrés comme référence.")


def cmd_monitor(args):
    config = load_config(args.config)
    setup_logging(config.log_file)
    engine = init_db(config.database)

    session_factory = lambda: get_session(engine)

    observer = start_watching(session_factory, config)

    stop_event = threading.Event()

    def periodic_rescan_loop():
        while not stop_event.wait(config.periodic_rescan_seconds):
            logging.getLogger("fim").info("Démarrage du rescan périodique...")
            session = get_session(engine)
            try:
                full_rescan(session, config)
            finally:
                session.close()
            logging.getLogger("fim").info("Rescan périodique terminé.")

    rescan_thread = threading.Thread(target=periodic_rescan_loop, daemon=True)
    rescan_thread.start()

    print(f"FIM actif. Surveillance temps réel + rescan toutes les {config.periodic_rescan_seconds}s. "
          f"Ctrl+C pour arrêter.")
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        observer.stop()
        stop_event.set()
        observer.join()
        print("Arrêt du FIM.")


def cmd_status(args):
    config = load_config(args.config)
    engine = init_db(config.database)
    session = get_session(engine)
    nb_files = session.query(FileBaseline).count()
    nb_events = session.query(FIMEvent).count()
    print(f"Fichiers suivis dans la baseline : {nb_files}")
    print(f"Événements enregistrés (total)   : {nb_events}")
    session.close()


def cmd_report(args):
    config = load_config(args.config)
    engine = init_db(config.database)
    session = get_session(engine)
    events = (session.query(FIMEvent)
              .order_by(FIMEvent.timestamp.desc())
              .limit(args.limit)
              .all())
    if not events:
        print("Aucun événement enregistré.")
    for e in events:
        print(f"[{e.timestamp}] {e.event_type:<20} {e.path}  {e.details or ''}")
    session.close()


def main():
    parser = argparse.ArgumentParser(description="FIM - File Integrity Monitoring")
    parser.add_argument("-c", "--config", default="config.yaml", help="Chemin du fichier de configuration")
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("init", help="Construit la baseline initiale").set_defaults(func=cmd_init)
    sub.add_parser("monitor", help="Démarre la surveillance temps réel").set_defaults(func=cmd_monitor)
    sub.add_parser("status", help="Affiche un résumé de l'état").set_defaults(func=cmd_status)

    report_parser = sub.add_parser("report", help="Affiche les derniers événements")
    report_parser.add_argument("--limit", type=int, default=50)
    report_parser.set_defaults(func=cmd_report)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
