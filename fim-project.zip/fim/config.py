"""Chargement et validation de la configuration FIM."""
import os
import yaml
from dataclasses import dataclass, field


@dataclass
class EmailConfig:
    enabled: bool = False
    smtp_server: str = ""
    smtp_port: int = 587
    use_tls: bool = True
    username: str = ""
    password: str = ""
    from_addr: str = ""
    to_addrs: list = field(default_factory=list)


@dataclass
class SlackConfig:
    enabled: bool = False
    webhook_url: str = ""


@dataclass
class DatabaseConfig:
    type: str = "sqlite"          # sqlite | postgresql
    path: str = "fim.db"          # utilisé si sqlite
    url: str = ""                 # utilisé si postgresql (SQLAlchemy URL complète)


@dataclass
class FIMConfig:
    watch_paths: list = field(default_factory=list)
    exclude_patterns: list = field(default_factory=list)
    hash_algorithm: str = "sha256"
    periodic_rescan_seconds: int = 3600
    database: DatabaseConfig = field(default_factory=DatabaseConfig)
    email: EmailConfig = field(default_factory=EmailConfig)
    slack: SlackConfig = field(default_factory=SlackConfig)
    log_file: str = "fim.log"


def load_config(path: str) -> FIMConfig:
    if not os.path.exists(path):
        raise FileNotFoundError(f"Fichier de configuration introuvable: {path}")

    with open(path, "r", encoding="utf-8") as f:
        raw = yaml.safe_load(f) or {}

    db_raw = raw.get("database", {})
    email_raw = raw.get("alerts", {}).get("email", {})
    slack_raw = raw.get("alerts", {}).get("slack", {})

    return FIMConfig(
        watch_paths=raw.get("watch_paths", []),
        exclude_patterns=raw.get("exclude_patterns", []),
        hash_algorithm=raw.get("hash_algorithm", "sha256"),
        periodic_rescan_seconds=raw.get("periodic_rescan_seconds", 3600),
        database=DatabaseConfig(
            type=db_raw.get("type", "sqlite"),
            path=db_raw.get("path", "fim.db"),
            url=db_raw.get("url", ""),
        ),
        email=EmailConfig(
            enabled=email_raw.get("enabled", False),
            smtp_server=email_raw.get("smtp_server", ""),
            smtp_port=email_raw.get("smtp_port", 587),
            use_tls=email_raw.get("use_tls", True),
            username=email_raw.get("username", ""),
            password=email_raw.get("password", ""),
            from_addr=email_raw.get("from_addr", ""),
            to_addrs=email_raw.get("to_addrs", []),
        ),
        slack=SlackConfig(
            enabled=slack_raw.get("enabled", False),
            webhook_url=slack_raw.get("webhook_url", ""),
        ),
        log_file=raw.get("log_file", "fim.log"),
    )
