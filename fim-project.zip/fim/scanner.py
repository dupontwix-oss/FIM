"""Construction de la baseline initiale et scans de vérification complets."""
import os
import fnmatch
import logging
from datetime import datetime, timezone

from fim.hasher import compute_hash, get_file_metadata
from fim.database import FileBaseline, FIMEvent
from fim.notifier import notify

logger = logging.getLogger("fim")


def is_excluded(path: str, patterns: list) -> bool:
    return any(fnmatch.fnmatch(path, pattern) for pattern in patterns)


def walk_watched_files(watch_paths: list, exclude_patterns: list):
    for base_path in watch_paths:
        if os.path.isfile(base_path):
            if not is_excluded(base_path, exclude_patterns):
                yield base_path
            continue
        for root, dirs, files in os.walk(base_path):
            for name in files:
                full_path = os.path.join(root, name)
                if not is_excluded(full_path, exclude_patterns):
                    yield full_path


def build_baseline(session, config):
    """Scanne tous les chemins surveillés et enregistre l'état de référence.
    À exécuter une seule fois à l'initialisation (ou après une revue de changements légitimes)."""
    count = 0
    for filepath in walk_watched_files(config.watch_paths, config.exclude_patterns):
        try:
            file_hash = compute_hash(filepath, config.hash_algorithm)
            meta = get_file_metadata(filepath)
        except (FileNotFoundError, PermissionError) as e:
            logger.warning(f"Impossible de lire {filepath}: {e}")
            continue

        existing = session.query(FileBaseline).filter_by(path=filepath).first()
        if existing:
            existing.hash = file_hash
            existing.size = meta["size"]
            existing.mtime = meta["mtime"]
            existing.permissions = meta["permissions"]
            existing.owner = meta["owner"]
            existing.last_checked = datetime.now(timezone.utc)
        else:
            session.add(FileBaseline(
                path=filepath,
                hash=file_hash,
                size=meta["size"],
                mtime=meta["mtime"],
                permissions=meta["permissions"],
                owner=meta["owner"],
            ))
        count += 1

    session.commit()
    logger.info(f"Baseline construite : {count} fichiers enregistrés.")
    return count


def full_rescan(session, config):
    """Scan complet de vérification : détecte modifications, suppressions et nouveaux fichiers
    qui n'ont pas été captés par les événements temps réel (ex: système redémarré, montage réseau)."""
    known_paths = {row.path: row for row in session.query(FileBaseline).all()}
    seen_paths = set()

    for filepath in walk_watched_files(config.watch_paths, config.exclude_patterns):
        seen_paths.add(filepath)
        try:
            current_hash = compute_hash(filepath, config.hash_algorithm)
            meta = get_file_metadata(filepath)
        except (FileNotFoundError, PermissionError) as e:
            logger.warning(f"Impossible de lire {filepath}: {e}")
            continue

        baseline = known_paths.get(filepath)
        if baseline is None:
            # nouveau fichier jamais vu
            session.add(FileBaseline(
                path=filepath, hash=current_hash, size=meta["size"],
                mtime=meta["mtime"], permissions=meta["permissions"], owner=meta["owner"],
            ))
            session.add(FIMEvent(path=filepath, event_type="CREATED", new_hash=current_hash,
                                  details="Détecté lors du rescan périodique"))
            notify(config, "CREATED", filepath, "Nouveau fichier détecté (rescan)")
        elif baseline.hash != current_hash:
            session.add(FIMEvent(path=filepath, event_type="MODIFIED",
                                  old_hash=baseline.hash, new_hash=current_hash,
                                  details="Détecté lors du rescan périodique"))
            notify(config, "MODIFIED", filepath, "Contenu modifié (rescan)")
            baseline.hash = current_hash
            baseline.size = meta["size"]
            baseline.mtime = meta["mtime"]
            baseline.permissions = meta["permissions"]
            baseline.owner = meta["owner"]
        elif baseline.permissions != meta["permissions"] or baseline.owner != meta["owner"]:
            session.add(FIMEvent(path=filepath, event_type="PERMISSION_CHANGED",
                                  details=f"perms {baseline.permissions}->{meta['permissions']}, "
                                          f"owner {baseline.owner}->{meta['owner']}"))
            notify(config, "PERMISSION_CHANGED", filepath, "Permissions ou propriétaire modifiés")
            baseline.permissions = meta["permissions"]
            baseline.owner = meta["owner"]

        baseline = session.query(FileBaseline).filter_by(path=filepath).first()
        if baseline:
            baseline.last_checked = datetime.now(timezone.utc)

    # fichiers connus mais disparus
    for path, baseline in known_paths.items():
        if path not in seen_paths:
            session.add(FIMEvent(path=path, event_type="DELETED", old_hash=baseline.hash,
                                  details="Détecté lors du rescan périodique"))
            notify(config, "DELETED", path, "Fichier surveillé supprimé (rescan)")
            session.delete(baseline)

    session.commit()
